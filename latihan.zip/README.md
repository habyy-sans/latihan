#latihan buat uts nanti - LATIHAN
 
 latihan uts
 